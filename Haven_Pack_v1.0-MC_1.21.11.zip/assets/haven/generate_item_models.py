import os
import json

ROOT = os.path.dirname(__file__)

MODELS_DIR = os.path.join(ROOT, "models")
ITEMS_DIR = os.path.join(ROOT, "items")

for root, dirs, files in os.walk(MODELS_DIR):

    rel_path = os.path.relpath(root, MODELS_DIR)

    # ignorar models/blocks
    if rel_path.startswith("blocks"):
        continue

    for file in files:
        if not file.endswith(".json"):
            continue

        model_name = file[:-5]

        # subpasta dentro de items
        item_folder = os.path.join(ITEMS_DIR, rel_path)
        os.makedirs(item_folder, exist_ok=True)

        model_ref = f"haven:{rel_path}/{model_name}".replace("\\", "/").replace("./", "")

        data = {
            "model": {
                "type": "minecraft:model",
                "model": model_ref
            }
        }

        item_path = os.path.join(item_folder, file)

        with open(item_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        print("Generated:", item_path)

print("Done.")